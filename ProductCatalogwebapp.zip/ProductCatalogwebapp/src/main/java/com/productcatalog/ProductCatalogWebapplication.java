package com.productcatalog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductCatalogWebapplication {

    public static void main(String[] args) {
        SpringApplication.run(ProductCatalogWebapplication.class, args);
    }
}
