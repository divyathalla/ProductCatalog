package com.productcatalog.domain;

/**
 * Created by jt on 11/14/15.
 */
public interface DomainObject {

    Integer getId();

    void setId(Integer id);
}
