package com.productcatalog.services;

import com.productcatalog.domain.Role;

public interface RoleService extends CRUDService<Role> {
}
